This project aims to introduce a stochastic approach to the computation of regional envelope curve. 
